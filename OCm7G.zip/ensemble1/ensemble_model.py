import os
import time
from collections import Counter
from random import seed

import torch
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold

from config.config import Config
from data.data import get_single_data
from dl.dl_model import TA
import numpy as np
import pandas as pd
import pickle as pkl
from ensemble1.model_factory import get_new_model
from prepare.prepare_dl import build_vocab, pretrain_one_hot, tokenizer, pretrain
from prepare.prepare_ml import ml_code, xgb_feature_selection
from tools.tools import get_label, score2


class StackingModel():

    def __init__(self, config):
        # self.base_models_name = ["RF","MNB","AB","GNB","LD","ET","GB","XGB"]
        self.base_models_name = ["RF", "AB", "LD", "ET", "GB", "XGB"]
        self.base_models = []
        self.meta_model = LogisticRegression()
        self.n_folds = 5
        self.best_features = None
        self.best_features_type = None
        self.config = config

    def fit(self, X, y):
        vocab = build_vocab(self.config.k)
        original_train_t = tokenizer(X, self.config.k)
        embedding1 = pretrain(original_train_t, vocab, self.config.embed)
        # embedding1 = pretrain_one_hot(vocab)
        self.config.embedding_pretrained = torch.FloatTensor(embedding1)
        self.config.vocab = vocab
        self.config.n_vocab = len(vocab)

        data_train1, label_train, record_feature_type = ml_code(X, "training")
        ml_X = pd.DataFrame(data_train1)
        if self.config.is_feature_selection:
            start1 = time.time()
            best_features = xgb_feature_selection(data_train1, label_train)
            end1 = time.time()
            print("Time consuming of feature selection:%.2f秒" % (end1 - start1))

            best_features_name = [record_feature_type[i] for i in best_features]
            best_features_type = dict(Counter(best_features_name))
            self.best_features = best_features
            self.best_features_type = best_features_type
            #save selected features
            file1 = open(self.config.features_save_path + self.config.model_name + "_features.pkl","wb")
            pkl.dump(self.best_features_type, file1)
            file1.close()
        else:
            best_features = list(range(ml_X.shape[1]))
            # best_features = [1, 2, 3, 4, 5, 6, 7]
            best_features_name = [record_feature_type[i] for i in best_features]
            best_features_type = dict(Counter(best_features_name))
            print(best_features_type)
            self.best_features = best_features
            self.best_features_type = best_features_type


        base_models_5fold_prediction = np.zeros((X.shape[0], len(self.base_models_name)+1))
        skf = list(StratifiedKFold(n_splits=self.n_folds).split(X, y))
        for j, model_name in enumerate(self.base_models_name):
            single_type_model = []
            for i, (train_index, val_index) in enumerate(skf):
                X_train, y_train, X_val, y_val = ml_X.iloc[train_index,self.best_features], y[train_index], ml_X.iloc[val_index,self.best_features], y[val_index]
                X_train = X_train.values
                X_val = X_val.values
                model = get_new_model(model_name)
                model.fit(X_train, y_train)
                y_pred = model.predict_proba(X_val)[:, 1]
                base_models_5fold_prediction[val_index, j] = y_pred
                single_type_model.append(model)
            print("single model ensemble(dev) for ",model_name,"：",score2(y,base_models_5fold_prediction[:,j]))
            self.base_models.append(single_type_model)

        # ---------------------dl----------------------------------------------------
        single_type_model = []
        for i, (train_index, val_index) in enumerate(skf):
            X_train, y_train, X_val, y_val = X.iloc[train_index, :], y[train_index], X.iloc[val_index, :], y[val_index]
            ta = TA(self.config)
            ta.fit(X_train, y_train)
            y_pred = ta.predict_proba(X_val)[:, 1]
            single_type_model.append(ta) # save model(all fold) to deal with test set
            base_models_5fold_prediction[val_index, len(self.base_models_name)] = y_pred
        print("single model ensemble(dev)：", score2(y, base_models_5fold_prediction[:, len(self.base_models_name)]))
        self.base_models.append(single_type_model)
        # ---------------------------------------------------------------------------
        # the 2th layer of ensemble learning model
        self.meta_model.fit(base_models_5fold_prediction, y)
        return self

    def predict(self, X,y_ind=None):
        X1, label_train, record_feature_type = ml_code(X, "testing")
        X1 = X1[:,self.best_features]
        base_models_ind_prediction = np.zeros((X.shape[0], len(self.base_models)))
        for i,single_type_models_list in enumerate(self.base_models):
            single_type_result = np.zeros((X.shape[0], len(self.base_models[0])))
            for j,model in enumerate(single_type_models_list):
                if i < len(self.base_models) - 1:
                    single_type_result[:, j] = model.predict_proba(X1)[:, 1]
                else:
                    single_type_result[:, j] = model.predict_proba(X)[:, 1]
            base_models_ind_prediction[:, i] = single_type_result.mean(1)
            print("单模型集成test：", score2(y_ind, base_models_ind_prediction[:, i]))
        y_pred = self.meta_model.predict_proba(base_models_ind_prediction)[:, 1]
        return y_pred


if __name__ == "__main__":
    # result_all = []
    # dataset_list = ["6mA_A.thaliana", "6mA_C.elegans", "6mA_C.equisetifolia", "6mA_D.melanogaster", "6mA_F.vesca",
    #                 "6mA_H.sapiens", "6mA_R.chinensis", "6mA_S.cerevisiae", "6mA_T.thermophile",
    #                 "6mA_Tolypocladium","6mA_Xoc BLS256"]
    # for dataset in dataset_list:
    start = time.time()
    seed1 = 1
    np.random.seed(seed1)
    torch.cuda.manual_seed(seed1)
    seed(seed1)
    os.environ['PYTHONHASHSEED'] = str(seed1)
    torch.manual_seed(seed1)
    torch.cuda.manual_seed_all(seed1)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    model_name = "2_200_0.001_2_128"
    # model_name = "2_400_0.001_3_128"

    config = Config("test")
    config.load_global_pretrain_model = False
    config.is_feature_selection = True
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-04-02 模型筛选/result20220404/select dataset/3st_loss/6mA_C.elegans.model"
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-04-02 模型筛选/result20220403/param select group2/"+model_name+".model"
    # config.global_model_save_path = "D:/python/mypaper/result_2022_0221/group1/pretrain_model/global_train_last.model"
    # config.global_model_save_path = "D:/python/mypaper/result_group2/global1.model"
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-04-02 模型筛选/result20220403/select dataset/a_2.model"
    config.global_model_save_path = "D:/python/jupyter/work_all/2022-03-24/result20220416/param select group2/"+model_name+".model"

    b = model_name.split("/")[-1]
    c = b.split("_")
    config.k = int(c[0])
    vocab = build_vocab(config.k)
    config.vocab = vocab
    config.n_vocab = len(vocab)
    # config.embed = 4 ** config.k
    # config.embed = 300
    config.embed = int(c[1])
    config.learning_rate = float(c[2])
    config.num_layers = int(c[3])
    # config.hidden_size = int(c[3])
    config.batch_size = int(c[4])
    config.dropout = 0
    config.num_check = 100
    config.num_epochs = 30

    dataset = "6mA_R.chinensis"
    config.model_name = dataset
    # dataset = "r_l"
    original_train1, original_test1 = get_single_data(dataset)
    train_label1 = get_label(original_train1)
    test_label1 = get_label(original_test1)
    sm = StackingModel(config)
    sm.fit(original_train1, train_label1)
    pred_prob = sm.predict(original_test1,test_label1)
    result_temp = score2(test_label1, pred_prob)
    print(result_temp)
    # result_all.append(result_temp)

    end = time.time()
    print("Time consuming:%.2f秒" % (end - start))
    # result_all = pd.DataFrame(result_all,index=dataset_list)
    # result_all.to_csv("d:/temp/result_group2_notran")



