import os
import time
from collections import Counter
from random import seed

import torch
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold

from config.config import Config
from data.data import get_single_data
from dl.dl_model import TA
import numpy as np
import pandas as pd
import pickle as pkl
from ensemble1.model_factory import get_new_model
from prepare.prepare_dl import build_vocab, pretrain_one_hot, tokenizer, pretrain
from prepare.prepare_ml import ml_code, xgb_feature_selection
from tools.tools import get_label, score2


class StackingModel():

    def __init__(self, config):
        # self.base_models_name = ["RF","MNB","AB","GNB","LD","ET","GB","XGB"]
        self.base_models_name = ["RF", "AB", "LD", "ET", "GB", "XGB"]
        # self.base_models_name = ["RF", "AB", "ET", "GB", "XGB"]
        self.base_models = []
        self.meta_model = LogisticRegression()
        self.n_folds = 5
        self.best_features = None
        self.best_features_type = None
        self.config = config

    def fit(self, X, y):
        vocab = build_vocab(self.config.k)
        original_train_t = tokenizer(X, self.config.k)
        embedding1 = pretrain(original_train_t, vocab, self.config.embed)
        # embedding1 = pretrain_one_hot(vocab)
        self.config.embedding_pretrained = torch.FloatTensor(embedding1)
        self.config.vocab = vocab
        self.config.n_vocab = len(vocab)





        base_models_5fold_prediction = np.zeros((X.shape[0], 1))
        skf = list(StratifiedKFold(n_splits=self.n_folds).split(X, y))


        # ---------------------dl----------------------------------------------------
        single_type_model = []
        for i, (train_index, val_index) in enumerate(skf):
            X_train, y_train, X_val, y_val = X.iloc[train_index, :], y[train_index], X.iloc[val_index, :], y[val_index]
            ta = TA(self.config)
            ta.fit(X_train, y_train)
            y_pred = ta.predict_proba(X_val)[:, 1]
            single_type_model.append(ta) # save model(all fold) to deal with test set
            base_models_5fold_prediction[val_index, 0] = y_pred
        print("single model ensemble(dev)：", score2(y, y_pred))
        self.base_models.append(single_type_model)
        # ---------------------------------------------------------------------------
        # the 2th layer of ensemble learning model
        # self.meta_model.fit(base_models_5fold_prediction, y)
        return self

    def predict(self, X,y_ind=None):
        # X1, label_train, record_feature_type = ml_code(X, "testing")
        # X1 = X1[:,self.best_features]
        base_models_ind_prediction = np.zeros((X.shape[0], 1))
        for i,single_type_models_list in enumerate(self.base_models):
            single_type_result = np.zeros((X.shape[0], len(self.base_models[0])))
            for j,model in enumerate(single_type_models_list):
                single_type_result[:, j] = model.predict_proba(X)[:, 1]
            base_models_ind_prediction[:, i] = single_type_result.mean(1)
            print("单模型集成test：", score2(y_ind, base_models_ind_prediction[:, i]))
        y_pred = self.meta_model.predict_proba(base_models_ind_prediction)[:, 1]
        return y_pred


if __name__ == "__main__":
    # result_all = []
    # dataset_list = ["h_b", "h_k", "h_l", "m_b", "m_h", "m_k","m_l", "m_t", "r_b", "r_k", "r_l"]
    # for dataset in dataset_list:
    start = time.time()
    seed1 = 1
    np.random.seed(seed1)
    torch.cuda.manual_seed(seed1)
    seed(seed1)
    os.environ['PYTHONHASHSEED'] = str(seed1)
    torch.manual_seed(seed1)
    torch.cuda.manual_seed_all(seed1)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    model_name = "3_0.001_3_128_128"
    # dataset = "h_k"
    config = Config("test")
    config.load_global_pretrain_model = True
    config.is_feature_selection = True
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-04-02 模型筛选/result20220404/select dataset/3st_loss/6mA_C.elegans.model"
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-04-02 模型筛选/result20220403/param select group2/"+model_name+".model"
    config.global_model_save_path = "D:/python/mypaper/result_2022_0221/group2/pretrain_model/global_train_last.model"
    # config.global_model_save_path = "D:/python/mypaper/result_group2/global1.model"
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-04-02 模型筛选/result20220403/select dataset/a_2.model"
    # config.global_model_save_path = "D:/python/jupyter/work_all/2022-03-24/result20220416/param select group2/"+model_name+".model"
    # dataset = "6mA_R.chinensis"
    dataset = "h_l"


    b = model_name.split("/")[-1]
    c = b.split("_")
    config.k = int(c[0])
    vocab = build_vocab(config.k)
    config.vocab = vocab
    config.n_vocab = len(vocab)
    # config.embed = 4 ** config.k
    config.embed = 400
    # config.embed = int(c[1])
    config.learning_rate = float(c[1])
    config.num_layers = int(c[2])
    config.hidden_size = int(c[3])
    config.batch_size = int(c[4])
    config.dropout = 0
    config.num_check = 100
    config.num_epochs = 30
    config.model_name = dataset


    original_train1, original_test1 = get_single_data(dataset)
    train_label1 = get_label(original_train1)
    test_label1 = get_label(original_test1)
    sm = StackingModel(config)
    sm.fit(original_train1, train_label1)
    pred_prob = sm.predict(original_test1,test_label1)
    result_temp = score2(test_label1, pred_prob)
    print(result_temp)
    # result_all.append(result_temp)

    end = time.time()
    print("Time consuming:%.2f秒" % (end - start))
    # result_all = pd.DataFrame(result_all,index=dataset_list)
    # result_all.to_csv("d:/temp/result_group2_notran.csv")



