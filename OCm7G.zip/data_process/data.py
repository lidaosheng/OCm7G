import numpy as np
import pandas as pd
import pickle as pkl
import random


def seqs_list2fasta(seqs_list, output_path):
    Note = open(output_path, mode='w')
    for idx, seq in enumerate(seqs_list):
        Note.writelines(['>' + str(idx) + '/n', seq + '/n'])  # /n 换行符
    print("finish...")



# read the raw reference genome by idx
def get_reference_genome(chr_id=1):
    # load reference genome(str)
    file_path = "M:/data/human_gene/new/hg19/split_all/chr" + str(chr_id) + ".txt"
    f1 = open(file_path, 'r')
    reference_genome_chr = f1.read()
    reference_genome_chr = reference_genome_chr.replace("\n", "")
    f1.close()
    return reference_genome_chr


# give the chr_id and central position, return the sequence with flanking(default 20)
def extract_seq(index_list, chr_id, flanking=20, strand="+"):
    reference_genome_chr = get_reference_genome(chr_id)
    reference_genome_chr = reference_genome_chr.upper()
    seq_list = []

    for index1 in index_list:
        # print("center:",reference_genome_chr[index1])
        # seq_temp = reference_genome_chr[index1 - flanking:index1 + flanking + 1]
        seq_temp = reference_genome_chr[index1 - flanking-1:index1 + flanking]
        if strand == "-":
            seq_temp = seq_temp.replace("A", "M")
            seq_temp = seq_temp.replace("T", "A")
            seq_temp = seq_temp.replace("M", "T")
            seq_temp = seq_temp.replace("C", "M")
            seq_temp = seq_temp.replace("G", "C")
            seq_temp = seq_temp.replace("M", "G")
            seq_temp = seq_temp[::-1]
        seq_list.append(seq_temp)
    return seq_list


def negative_sampling(positive_df, chr_id=1, base=("A", "T"), flanking=20):
    '''
    1.只保留离开甲基化位点至少20bp的A碱基
    :return: negative sequences list
    '''
    #     positive_index_list = positive_df[positive_df["chromosome"]=="chr"+str(chr_id)]["modStart"].values.tolist() #positive index on +
    positive_index_list = positive_df[positive_df.iloc[:, 1] == "chr" + str(chr_id)].iloc[:, 2].values.astype(
        int).tolist()  # positive index on +
    reference_genome_chr = get_reference_genome(chr_id)

    As_index = []
    # 筛选所有的A，以及其位置
    for idx, char1 in enumerate(reference_genome_chr):
        if char1 == base[0]:
            As_index.append(idx)

    Ts_index = []
    # 筛选所有的T，以及其位置
    for idx, char1 in enumerate(reference_genome_chr):
        if char1 == base[1]:
            Ts_index.append(idx)

    # create positive area index set
    pos_index_area = []
    for pos_index in positive_index_list:
        temp_area = [i for i in range(pos_index - flanking, pos_index + flanking + 1, 1)]
        pos_index_area.extend(temp_area)
    pos_index_area = set(pos_index_area)

    # filter negative samples
    negative_index_list_A = []
    for a_index in As_index:
        if a_index not in pos_index_area:
            negative_index_list_A.append(a_index)
    # subtract negative sequence by index
    negative_seq_list_A = extract_seq(negative_index_list_A, chr_id, 20, "+")

    negative_index_list_T = []
    for t_index in Ts_index:
        if t_index not in pos_index_area:
            negative_index_list_T.append(t_index)

    # subtract negative sequence by index
    negative_seq_list_T = extract_seq(negative_index_list_T, chr_id, 20, "-")
    negative_seq_list_T = [x[::-1] for x in negative_seq_list_T]

    negative_seq_list = negative_seq_list_A + negative_seq_list_T

    return negative_seq_list


if __name__ == "__main__":
    index_list = [1505449]

    seq = extract_seq(index_list, chr_id='X', flanking=20, strand="-")
    print(seq)