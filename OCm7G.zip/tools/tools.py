import random
import numpy as np
import pandas as pd
import os
from random import seed
import tensorflow as tf
import multiprocessing as mp
import heartrate
from lightgbm import LGBMClassifier
from tqdm import tqdm
from colorama import Fore
from sklearn.metrics import confusion_matrix, roc_auc_score, matthews_corrcoef, f1_score
from fs.encode1 import ENAC2, binary, NCP, EIIP, CKSNAP, ENAC, Kmer, NAC, PseEIIP, ANF, CKSNAP8, Kmer4, TNC, RCKmer5, \
    DNC



def set_global_determinism(seed1=0):
    set_seeds(seed1)

    os.environ['TF_DETERMINISTIC_OPS'] = '1'
    os.environ['TF_CUDNN_DETERMINISTIC'] = '1'

    tf.config.threading.set_inter_op_parallelism_threads(1)
    tf.config.threading.set_intra_op_parallelism_threads(1)

def select_thre3(y_test,y_pred,num_thre=1000):
    thre = np.linspace(0, 1, num_thre).reshape(-1,1)
    y_pred2 = y_pred.reshape(1,-1)
    y_pred2 = np.repeat(y_pred2, num_thre, axis=0)
    y_pred2 = y_pred2 - thre
    y_pred2[y_pred2 > 0] = 1
    y_pred2[y_pred2 < 0] = 0
    pool = mp.Pool()
    # mccs = list(pool.map(lambda x:matthews_corrcoef(y_test,x),y_pred2))
    mccs = list(pool.map(matthews_corrcoef,y_test,y_pred2))
    index2 = mccs.index(max(mccs))
    rr_max = thre[index2]
    return rr_max

# def select_thre2(y_test,y_pred,num_thre=1000):
#     thre = np.linspace(0, 1, num_thre).reshape(-1,1)
#
#     y_test2 = y_test.reshape(1, -1)
#     y_test2 = np.repeat(y_test2, num_thre, axis=0)
#
#     y_pred2 = y_pred.reshape(1,-1)
#     y_pred2 = np.repeat(y_pred2, num_thre, axis=0)
#     y_pred2 = y_pred2 - thre
#     y_pred2[y_pred2 > 0] = 1
#     y_pred2[y_pred2 < 0] = 0
#     # mccs = map(lambda x:matthews_corrcoef(y_test,x),y_pred2)
#     # mccs = np.apply_along_axis(matthews_corrcoef, 0,y_test, y_pred2)
#
#     fa = pd.DataFrame({"a": y_test2.tolist(), "b": y_pred2.tolist()})
#     mccs = fa.apply(lambda x: matthews_corrcoef(x[0], x[1]), axis=1).values
#
#     mccs = list(mccs)
#     index2 = mccs.index(max(mccs))
#     rr_max = thre[index2]
#     return rr_max
# Time consuming:161.89秒
# Time consuming:325.43秒
# Time consuming:487.32秒

def select_thre(y_test,y_pred,num_thre=1000):
    thre = np.linspace(0, 1, num_thre).reshape(-1,1)
    # thre = np.linspace(0.490, 0.510, num_thre).reshape(-1,1)
    y_pred2 = y_pred.reshape(1,-1)
    y_pred2 = np.repeat(y_pred2, num_thre, axis=0)
    y_pred2 = y_pred2 - thre
    y_pred2[y_pred2 > 0] = 1
    y_pred2[y_pred2 < 0] = 0
    mccs = map(lambda x:matthews_corrcoef(y_test,x),y_pred2)
    mccs = list(mccs)
    index2 = mccs.index(max(mccs))
    rr_max = thre[index2]
    return rr_max

def select_thre2(y_test,y_pred,num_thre=1000):
    thre = np.linspace(0, 1, num_thre).reshape(-1,1)
    # thre = np.linspace(0.2, 0.4, num_thre).reshape(-1,1)
    y_pred2 = y_pred.reshape(1,-1)
    y_pred2 = np.repeat(y_pred2, num_thre, axis=0)
    y_pred2 = y_pred2 - thre
    y_pred2[y_pred2 > 0] = 1
    y_pred2[y_pred2 < 0] = 0
    mccs = map(lambda x:matthews_corrcoef(y_test,x),y_pred2)
    mccs = list(mccs)
    index2 = mccs.index(max(mccs))
    rr_max = thre[index2]
    return rr_max

# 阈值筛选4
# 同样是计算阈值，不过是从
def select_thre4(y_test,y_pred,num_thre=1000):
    thre_max = max(y_pred)
    thre_min = min(y_pred)
    thre = np.linspace(thre_min, thre_max, num_thre).reshape(-1,1)
    # thre = np.linspace(0.490, 0.510, num_thre).reshape(-1,1)
    y_pred2 = y_pred.reshape(1,-1)
    y_pred2 = np.repeat(y_pred2, num_thre, axis=0)
    y_pred2 = y_pred2 - thre
    y_pred2[y_pred2 > 0] = 1
    y_pred2[y_pred2 < 0] = 0
    mccs = map(lambda x:matthews_corrcoef(y_test,x),y_pred2)
    mccs = list(mccs)
    index2 = mccs.index(max(mccs))
    rr_max = thre[index2]
    return rr_max



def remove_number(ss):
    ss1 = ss
    for i in range(10):
        ss1 = ss1.replace(str(i), '')
    return ss1


def read_seq_data(file_path):
    '''
    Arguments:
    file_path -- （"../data/test.txt"）

    Return:
    seq_data -- DataFrame，（label，seq）
    '''
    m = []
    with open(file_path, "r") as f:
        lines = ""
        for line in f.readlines():
            line = line.upper().strip()
            if line.startswith(">"):
                if lines != "":
                    m.append([key, lines])
                    lines = ""
                key = line[1:]
            else:
                line = remove_number(line)
                # line = line.replace("T", "U")
                lines += line
    m.append([key, lines])
    seq_data = pd.DataFrame(m, columns=["label", "seq"])
    seq_data["label"] = seq_data["label"].apply(lambda x: (0 if x.find('|1|') == -1 else 1)).tolist()
    # seq_data["label"] = seq_data["label"].apply(lambda x: (1 if x.find('NEGATIVE') == -1 else 0)).tolist()
    return seq_data




def seq_to01_to0123(seq):

#     seq, label = read_seq_label(filename)

    nrows = len(seq)
    seq_len = len(seq[0])

    seq_01 = np.zeros((nrows, seq_len, 4), dtype='int')
    seq_0123 = np.zeros((nrows, seq_len), dtype='int')

    for i in range(nrows):
        one_seq = seq[i]
        one_seq = one_seq.replace('A', '0')
        one_seq = one_seq.replace('C', '1')
        one_seq = one_seq.replace('G', '2')
        one_seq = one_seq.replace('U', '3')
        one_seq = one_seq.replace('T', '3')

        one_seq = one_seq.replace('a', '0')
        one_seq = one_seq.replace('c', '1')
        one_seq = one_seq.replace('g', '2')
        one_seq = one_seq.replace('u', '3')
        one_seq = one_seq.replace('t', '3')

        one_seq = one_seq.replace('N', '9')
        one_seq = one_seq.replace('-', '9')
        seq_start = 0
        for j in range(seq_len):
            seq_0123[i, j] = int(one_seq[j - seq_start])
            if j < seq_start:
                seq_01[i, j, :] = 0
            else:
                try:
                    seq_01[i, j, int(one_seq[j - seq_start])] = 1
                except:
                    seq_01[i, j, :] = 0
    return seq_01, seq_0123

def set_seeds(seed1=0):
    os.environ['PYTHONHASHSEED'] = str(seed1)
    seed(seed1)
    tf.random.set_seed(seed1)
    np.random.seed(seed1)


def set_global_determinism(seed1=0):
    set_seeds(seed1)

    os.environ['TF_DETERMINISTIC_OPS'] = '1'
    os.environ['TF_CUDNN_DETERMINISTIC'] = '1'

    tf.config.threading.set_inter_op_parallelism_threads(1)
    tf.config.threading.set_intra_op_parallelism_threads(1)
# 单类型样本训练：平均ACC 平均AUC，9个（样本数量和样本类型）
# 按数量分层抽样
# def sample_h(dataset,label,sample_num):
# 单类型样本训练：平均ACC 平均AUC，9个（样本数量和样本类型）
# 按数量分层抽样
# def sample_h(dataset,label,sample_num):
def sample_h(seqs_df, pos_num_choose):
    data_size = seqs_df.shape[0]
    labels = [(0 if x.find('+') == -1 else 1) for x in seqs_df["seq_id"]]
    labels_index = np.array(range(0, data_size))
    labels_p = [(True if value == 1 else False) for value in labels]
    labels_n = [(True if value == 0 else False) for value in labels]
    labels_p = set(labels_index[labels_p])  # 正样本下标
    labels_n = set(labels_index[labels_n])  # 负样本下标

    indexes_shuffle_p = np.random.choice(list(labels_p), len(labels_p), replace=False)  # 打乱顺序
    indexes_shuffle_n = np.random.choice(list(labels_n), len(labels_n), replace=False)  # 打乱顺序

    indexes_choose_p, indexes_choose_n = list(indexes_shuffle_p[:pos_num_choose]), list(
        indexes_shuffle_n[:pos_num_choose])
    indexes_remain_p, indexes_remain_n = list(indexes_shuffle_p[pos_num_choose:]), list(
        indexes_shuffle_n[pos_num_choose:])

    indexes_choose_p.extend(indexes_choose_n)
    indexes_remain_p.extend(indexes_remain_n)

    random.shuffle(indexes_choose_p)
    random.shuffle(indexes_remain_p)

    return seqs_df.iloc[indexes_choose_p, :], seqs_df.iloc[indexes_remain_p, :]

'''
将序列数据框分层抽样，打乱顺序后，并保持原有格式
'''
def split_seq_df(data,freq=0.2):
    labels = get_label(data)
    # get pos and neg sample index
    labels_index = np.array(range(0, data.shape[0]))
    labels_p = [(True if value == 1 else False) for value in labels]
    labels_n = [(True if value == 0 else False) for value in labels]
    labels_p = set(labels_index[labels_p])
    labels_n = set(labels_index[labels_n])
    # extract train index and test index by freq and class
    labels_p_test = set(random.sample(labels_p, int(len(labels_p) * freq)))
    labels_n_test = set(random.sample(labels_n, int(len(labels_n) * freq)))
    labels_p_train = labels_p.difference(labels_p_test)
    labels_n_train = labels_n.difference(labels_n_test)
    labels_train = list(labels_p_train.union(labels_n_train))
    labels_test = list(labels_p_test.union(labels_n_test))

    random.shuffle(labels_train)
    random.shuffle(labels_test)

    # data_train = [data[x] for x in labels_train]
    # data_test = [data[x] for x in labels_test]

    data_train = data.iloc[labels_train,:]
    data_test = data.iloc[labels_test, :]
    return data_train, data_test



def split_h(data, label1=None, freq=0.2):
    data_size = len(data)
    data1 = pd.DataFrame(data)
    if label1 is None:
        labels = np.array(data1.iloc[:, 1])
    else:
        labels = np.array(label1)
    labels_index = np.array(range(0, data_size))
    labels_p = [(True if value == 1 else False) for value in labels]
    labels_n = [(True if value == 0 else False) for value in labels]
    labels_p = set(labels_index[labels_p])
    labels_n = set(labels_index[labels_n])

    labels_p_test = set(random.sample(labels_p, int(len(labels_p) * freq)))
    labels_n_test = set(random.sample(labels_n, int(len(labels_n) * freq)))
    labels_p_train = labels_p.difference(labels_p_test)
    labels_n_train = labels_n.difference(labels_n_test)
    labels_train = list(labels_p_train.union(labels_n_train))
    labels_test = list(labels_p_test.union(labels_n_test))

    random.shuffle(labels_train)
    random.shuffle(labels_test)

    if type(data)==pd.core.frame.DataFrame:

        data_train = data.iloc[labels_train,:]
        data_test = data.iloc[labels_test,:]
        print(data_test.shape)
    else:
        data_train = np.array([data[x] for x in labels_train])
        data_test = np.array([data[x] for x in labels_test])

    if label1 is None:
        return data_train, data_test
    else:
        return data_train, data_test, labels[labels_train], labels[labels_test]


def split_h2(data, freq=0.2):
    data_size = len(data)
    data1 = pd.DataFrame(data)
    labels = np.array(data1.iloc[:, 1])
    labels_index = np.array(range(0, data_size))
    labels_p = [(True if value == 1 else False) for value in labels]
    labels_n = [(True if value == 0 else False) for value in labels]
    labels_p = set(labels_index[labels_p])
    labels_n = set(labels_index[labels_n])

    labels_p_test = set(random.sample(labels_p, int(len(labels_p) * freq)))
    labels_n_test = set(random.sample(labels_n, int(len(labels_n) * freq)))
    labels_p_train = labels_p.difference(labels_p_test)
    labels_n_train = labels_n.difference(labels_n_test)
    labels_train = list(labels_p_train.union(labels_n_train))
    labels_test = list(labels_p_test.union(labels_n_test))

    random.shuffle(labels_train)
    random.shuffle(labels_test)

    # data_train = [data[x] for x in labels_train]
    # data_test = [data[x] for x in labels_test]

    data_train = data.iloc[labels_train,:]
    data_test = data.iloc[labels_test,:]

    return data_train, data_test


def sample_h(seqs_df, sample_num_half):
    data_size = seqs_df.shape[0]
    # labels = [(0 if x.find('+') == -1 else 1) for x in seqs_df["seq_id"]]
    labels = seqs_df["label"].values
    labels_index = np.array(range(0, data_size))
    labels_p = [(True if value == 1 else False) for value in labels]
    labels_n = [(True if value == 0 else False) for value in labels]
    labels_p = set(labels_index[labels_p])  # 正样本下标
    labels_n = set(labels_index[labels_n])  # 负样本下标

    indexes_shuffle_p = np.random.choice(list(labels_p), len(labels_p), replace=False)  # 打乱顺序
    indexes_shuffle_n = np.random.choice(list(labels_n), len(labels_n), replace=False)  # 打乱顺序

    indexes_choose_p, indexes_choose_n = list(indexes_shuffle_p[:sample_num_half]), list(
        indexes_shuffle_n[:sample_num_half])
    indexes_remain_p, indexes_remain_n = list(indexes_shuffle_p[sample_num_half:]), list(
        indexes_shuffle_n[sample_num_half:])

    indexes_choose_p.extend(indexes_choose_n)
    indexes_remain_p.extend(indexes_remain_n)

    random.shuffle(indexes_choose_p)
    random.shuffle(indexes_remain_p)
    data_choose = seqs_df.iloc[indexes_choose_p, :]
    data_remain = seqs_df.iloc[indexes_remain_p, :]
    data_choose.index = range(data_choose.shape[0])
    data_remain.index = range(data_remain.shape[0])
    return data_choose,data_remain




def num2vec(label1):
    result = []
    for l1 in label1:
        vec = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        if l1 == 0:
            pass
        else:
            vec[l1 - 1] = 1
        result.append(vec)
    return np.array(result)

def score2(y_real, pre_label,thred=0.5):
    auc1 = roc_auc_score(y_real, pre_label)
    pre_label_acc = [(1 if x >thred  else 0) for x in pre_label]
    # from collections import Counter
    # print("pred:",Counter(pre_label_acc),"real:",Counter(y_real))
    # print(pre_label_acc)
    cm = confusion_matrix(y_real, pre_label_acc)
    # print(cm)
    tn = cm[0][0]
    fp = cm[0][1]
    fn = cm[1][0]
    tp = cm[1][1]
    acc = (tp + tn) / (tp + fp + fn + tn)
    pre = tp/(tp+fp)
    #     rec = tp/(tp+fn)
    spec = tn / (tn + fp)  # SP
    sens = tp / (tp + fn)  # SN
    mcc = matthews_corrcoef(y_real, pre_label_acc)  # 根据CPU中的，计算ACC
    f1score = f1_score(y_real, pre_label_acc)
    #     print("acc2:",acc,"SN:",sens,"SP:",spec,"mcc:",mcc,"auc:",auc1,"f1score:",f1score)
    return acc, sens, spec, mcc, auc1, f1score,pre

def score21(y_real, pre_label,thred=0.5):
    auc1 = roc_auc_score(y_real, pre_label)
    pre_label_acc = [(1 if x >thred  else 0) for x in pre_label]
    # from collections import Counter
    # print("pred:",Counter(pre_label_acc),"real:",Counter(y_real))
    # print(pre_label_acc)
    cm = confusion_matrix(y_real, pre_label_acc)
    # print(cm)
    tn = cm[0][0]
    fp = cm[0][1]
    fn = cm[1][0]
    tp = cm[1][1]
    # print("score21:", tn, tp, fn, fp)
    acc = (tp + tn) / (tp + fp + fn + tn)
    pre = tp/(tp+fp)
    rec = tp/(tp+fn)
    spec = tn / (tn + fp)  # SP
    sens = tp / (tp + fn)  # SN
    mcc = matthews_corrcoef(y_real, pre_label_acc)  # 根据CPU中的，计算ACC
    f1score = f1_score(y_real, pre_label_acc)
    #     print("acc2:",acc,"SN:",sens,"SP:",spec,"mcc:",mcc,"auc:",auc1,"f1score:",f1score)
    return acc, sens, spec,pre,rec, mcc, auc1, f1score



def score22(y_real, pre_label,thred=0.5,ratio=1):
    y_real = list(y_real)
    pre_label = list(pre_label)

    y_real.extend([0.0]*int(len(y_real)*ratio))
    y_pred3 = [0.0]*(int(len(pre_label)*ratio)  -1)+[1.0]
    pre_label.extend(y_pred3)
    y_real = np.array(y_real)
    pre_label =  np.array(pre_label)
    auc1 = roc_auc_score(y_real, pre_label)
    pre_label_acc = [(1 if x >thred  else 0) for x in pre_label]
    cm = confusion_matrix(y_real, pre_label_acc)
    # print(cm)
    tn = cm[0][0]
    fp = cm[0][1]
    fn = cm[1][0]
    tp = cm[1][1]
    # print("score22:",tn,tp,fn,fp)
    acc = (tp + tn) / (tp + fp + fn + tn)
    pre = tp/(tp+fp)
    rec = tp/(tp+fn)
    spec = tn / (tn + fp)  # SP
    sens = tp / (tp + fn)  # SN
    mcc = matthews_corrcoef(y_real, pre_label_acc)  # 根据CPU中的，计算ACC
    f1score = f1_score(y_real, pre_label_acc)
    #     print("acc2:",acc,"SN:",sens,"SP:",spec,"mcc:",mcc,"auc:",auc1,"f1score:",f1score)
    return acc, sens, spec,pre,rec, mcc, auc1, f1score



def score3(y_real, pre_label,pre_prob):
    auc1 = roc_auc_score(y_real, pre_prob)
    cm = confusion_matrix(y_real, pre_label)
    tn = cm[0][0]
    fp = cm[0][1]
    fn = cm[1][0]
    tp = cm[1][1]
    acc = (tp + tn) / (tp + fp + fn + tn)
    spec = tn / (tn + fp)  # SP
    sens = tp / (tp + fn)  # SN
    mcc = matthews_corrcoef(y_real, pre_label)  # 根据CPU中的，计算ACC
    f1score = f1_score(y_real, pre_label)
    #     print("acc2:",acc,"SN:",sens,"SP:",spec,"mcc:",mcc,"auc:",auc1,"f1score:",f1score)
    return acc, sens, spec, mcc, auc1, f1score



def get_label(seqs_df):
    label = seqs_df["label"].values
    return label


import matplotlib.pyplot as plt
from sklearn import manifold, datasets
from matplotlib.colors import ListedColormap

def plot_tsne(X,y,name1=""):
    '''t-SNE'''
    # tsne = manifold.TSNE(n_components=2, init='pca', random_state=501)
    tsne = manifold.TSNE(n_components=2, random_state=501)
    X_tsne = tsne.fit_transform(X)
    colours = ListedColormap(['r', 'b', 'g', 'y', 'm'])
    print("Org data dimension is {}. Embedded data dimension is {}".format(X.shape[-1], X_tsne.shape[-1]))

    '''嵌入空间可视化'''
    x_min, x_max = X_tsne.min(0), X_tsne.max(0)
    X_norm = (X_tsne - x_min) / (x_max - x_min)  # 归一化
    plt.figure(figsize=(8, 8))
    for i in range(X_norm.shape[0]):
        # plt.text(X_norm[i, 0], X_norm[i, 1], str(y[i]), color=plt.cm.Set1(y[i]),fontdict={'weight': 'bold', 'size': 9})
        plt.text(X_norm[i, 0], X_norm[i, 1], str('o'), color=plt.cm.Set1(y[i]),fontdict={'weight': 'bold', 'size': 9})

    plt.title("t-SNE")
    plt.xticks([])
    plt.yticks([])
    plt.show()

def plot_tsne2(X,y,save_path,name1="",model_name=""):
    '''t-SNE'''
    # tsne = manifold.TSNE(n_components=2, random_state=0)
    tsne = manifold.TSNE(n_components=2, init='pca', random_state=0)
    labels_p = [(True if value == 1 else False) for value in y]
    labels_n = [(True if value == 0 else False) for value in y]


    X_tsne = tsne.fit_transform(X)
    colours = ListedColormap(['r', 'b', 'g', 'y', 'm'])
    print("Org data dimension is {}. Embedded data dimension is {}".format(X.shape[-1], X_tsne.shape[-1]))
    color1 = ['red','blue']
    '''嵌入空间可视化'''
    # x_min, x_max = X_tsne.min(0), X_tsne.max(0)
    # X_norm = (X_tsne - x_min) / (x_max - x_min)  # 归一化
    plt.figure(figsize=(8, 8))
    ps1 = []
    ps2 = []

    X_p = X_tsne[labels_p]
    X_n = X_tsne[labels_n]
    # for i in range(X_p.shape[0]):
    p1 = plt.scatter(X_p[:, 0], X_p[:, 1], color=color1[0], alpha=0.5, s=7,label="pos")
    p2 = plt.scatter(X_n[:, 0], X_n[:, 1], color=color1[1], alpha=0.5, s=7,label="neg")
        # ps1.append(p1)
        # ps2.append(p2)

    plt.title("t-SNE "+model_name+" "+name1)
    plt.xticks([])
    plt.yticks([])

    plt.legend()
    plt.savefig(save_path + name1 + "_" + model_name + ".pdf")
    plt.show()

def load_data(dataset):
    dir1 = dataset.split("_")[0]
    train_pos = "M:/work/paper3_6/data/" + dir1 + "/" + dataset + "/train_pos.txt"
    train_neg = "M:/work/paper3_6/data/" + dir1 + "/" + dataset + "/train_neg.txt"
    test_pos = "M:/work/paper3_6/data/" + dir1 + "/" + dataset + "/test_pos.txt"
    test_neg = "M:/work/paper3_6/data/" + dir1 + "/" + dataset + "/test_neg.txt"

    data_train_pos = pd.read_table(train_pos, header=None)
    data_train_neg = pd.read_table(train_neg, header=None)
    data_test_pos = pd.read_table(test_pos, header=None)
    data_test_neg = pd.read_table(test_neg, header=None)

    train_seq = data_train_pos.iloc[:, 0].values.tolist() + data_train_neg.iloc[:, 0].values.tolist()
    train_seq_id = [1] * data_train_pos.shape[0] + [0] * data_train_neg.shape[0]
    data_train = pd.DataFrame({"label": train_seq_id, "seq": train_seq})

    data_train["seq"] = data_train["seq"].apply(lambda x: x.replace("T", 'U'))

    test_seq = data_test_pos.iloc[:, 0].values.tolist() + data_test_neg.iloc[:, 0].values.tolist()
    test_seq_id = [1] * data_test_pos.shape[0] + [0] * data_test_neg.shape[0]
    data_test = pd.DataFrame({"label": test_seq_id, "seq": test_seq})
    data_test["seq"] = data_test["seq"].apply(lambda x: x.replace("T", 'U'))

    return data_train, data_test






def plot_tsne3(X,y,save_path,name1="",model_name=""):
    '''t-SNE'''
    # tsne = manifold.TSNE(n_components=2, random_state=0)
    tsne = manifold.TSNE(n_components=2, init='pca', random_state=0)
    labels_p = [(True if value == 1 else False) for value in y]
    labels_n = [(True if value == 0 else False) for value in y]


    X_tsne = tsne.fit_transform(X)
    colours = ListedColormap(['r', 'b', 'g', 'y', 'm'])
    print("Org data dimension is {}. Embedded data dimension is {}".format(X.shape[-1], X_tsne.shape[-1]))
    color1 = ['red','blue']
    '''嵌入空间可视化'''
    x_min, x_max = X_tsne.min(0), X_tsne.max(0)
    X_norm = (X_tsne - x_min) / (x_max - x_min)  # 归一化
    plt.figure(figsize=(8, 8))

    X_p = X_norm[labels_p]
    X_n = X_norm[labels_n]
    # for i in range(X_p.shape[0]):
    p1 = plt.scatter(X_p[:, 0], X_p[:, 1], color=color1[0], alpha=0.6, s=8,label="pos")
    p2 = plt.scatter(X_n[:, 0], X_n[:, 1], color=color1[1], alpha=0.6, s=8,label="neg")
        # ps1.append(p1)
        # ps2.append(p2)

    plt.title("t-SNE "+model_name+" "+name1)
    plt.xticks([])
    plt.yticks([])

    plt.legend()
    # plt.savefig(save_path + name1 + "_" + model_name + ".pdf")
    plt.show()

def plot_tsne4(X,y,save_path,name1="",model_name=""):
    '''t-SNE'''
    # tsne = manifold.TSNE(n_components=2, random_state=0)
    labels_p = [(True if value == 1 else False) for value in y]
    labels_n = [(True if value == 0 else False) for value in y]

    color1 = ['red','blue']
    '''嵌入空间可视化'''
    plt.figure(figsize=(8, 8))
    ps1 = []
    ps2 = []

    X_p = X[labels_p]
    X_n = X[labels_n]
    # for i in range(X_p.shape[0]):
    p1 = plt.scatter(X_p[:, 0], X_p[:, 1], color=color1[0], alpha=0.6, s=8,label="pos")
    p2 = plt.scatter(X_n[:, 0], X_n[:, 1], color=color1[1], alpha=0.6, s=8,label="neg")
        # ps1.append(p1)
        # ps2.append(p2)

    plt.title(" "+model_name+" "+name1)
    plt.xticks([])
    plt.yticks([])

    plt.legend()
    # plt.savefig(save_path + name1 + "_" + model_name + ".pdf")
    plt.show()

