import os
from collections import Counter
import pickle as pkl
import numpy as np
from prepare.prepare_ml import ml_code
from tools.tools import split_seq_df, get_label, seq_to01_to0123, read_seq_data
import random
import pandas as pd
from fs.encode1 import ENAC2, CKSNAP8, binary, ANF, NCP, EIIP, Kmer4, DNC, NAC, PseEIIP, RCKmer4

def get_single_data_m7G():
    data_train_pos = read_seq_data("D:/python/第三篇/同类算法对比/m7G/Positive.txt")
    data_train_neg = read_seq_data("D:/python/第三篇/同类算法对比/m7G/Negative.txt")
    data_test_pos = read_seq_data("D:/python/第三篇/同类算法对比/m7G/Ind-positive.txt")
    data_test_neg = read_seq_data("D:/python/第三篇/同类算法对比/m7G/Ind-negative.txt")
    data_train = pd.concat([data_train_pos,data_train_neg],axis=0)
    data_test = pd.concat([data_test_pos, data_test_neg], axis=0)
    label_train = [1] * data_train_pos.shape[0] + [0] * data_train_neg.shape[0]
    label_test = [1] * data_test_pos.shape[0] + [0] * data_test_neg.shape[0]
    data_train["label"] = label_train
    data_test["label"] = label_test

    return data_train,data_test



