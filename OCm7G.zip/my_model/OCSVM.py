from sklearn.svm import OneClassSVM
import numpy as np

class MyClassifier:
    def __init__(self, nu=0.1,gamma=0.1):
        self.threshold = 0.5
        self.nu = nu
        self.gamma = gamma
        self.scaler = 100
        self.clf = OneClassSVM(nu=self.nu,gamma=self.gamma)

    def set_threshold(self,threshold):
        self.threshold = threshold

    def get_threshold(self):
        return self.threshold

    def set_params(self, **params):
        for parameter, value in params.items():
            setattr(self, parameter, value)
        self.clf.set_params(**params)
        return self

    def get_params(self, deep=True):
        return {"nu": self.nu, "gamma": self.gamma}


    def fit(self, X, y=None):
        self.classes_ = np.unique(y)
        self.clf.fit(X)
        return self

    def predict(self, X):
        y_pred = self.clf.predict(X)
        # y_pred[y_pred == 1] = 0  # 将OneClassSVM中标记为1的样本标记为0
        y_pred[y_pred == -1] = 0  # 将OneClassSVM中标记为-1的样本标记为1
        return y_pred

    def predict_proba(self,X):
        dis = self.clf.decision_function(X)
        y_pred = np.array(dis) * self.scaler
        y_pred = 1 / (1 + np.exp(-y_pred))
        return y_pred

