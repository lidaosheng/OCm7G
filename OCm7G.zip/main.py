import time
from itertools import product
import pickle as pkl
import numpy as np
import pandas as pd
from sklearn.svm import OneClassSVM
import os

import random
from tqdm import tqdm
from colorama import Fore
import warnings

from data_process.data_process import get_single_data_m7G
from fs.encode1 import ENAC2, binary, NCP, EIIP, CKSNAP, ENAC, Kmer, NAC, PseEIIP, ANF, CKSNAP8, Kmer4, TNC, RCKmer5, \
    DNC
from fs.load_acc import TAC
from fs.load_pse import  SCPseTNC, PCPseTNC
from prepare.prepare_ml import ml_code

warnings.filterwarnings("ignore")


from tools.tools import score22, score21, select_thre, select_thre2, split_seq_df, get_label
def encoding_all(seq_df,encoding):
    if encoding is None:
        encoding = {"ENAC": ENAC2, "binary": binary, "NCP": NCP, "EIIP": EIIP, "Kmer4": Kmer4, "CKSNAP": CKSNAP8,
                             "PseEIIP": PseEIIP, "TNC": TNC, "RCKmer5": RCKmer5, "SCPseTNC": SCPseTNC, "PCPseTNC": PCPseTNC,
                             "ANF": ANF, "NAC": NAC, "TAC": TAC}
    X_ml, y_ml, record_feature_type = ml_code(seq_df, encoding, "training")
    X_2 = np.zeros([X_ml.shape[0],1])
    X_ml2 = np.hstack([X_ml,X_2])
    X = X_ml2.astype("float32")
    return X,y_ml

def zero_one(list1):
    max_1 = max(list1)
    min_1 = min(list1)
    list2 = [(x - min_1) / (max_1 - min_1) for x in list1]
    return list2


if __name__ == "__main__":
    seed = 0
    np.random.seed(seed)
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    start_start = time.time()
    start = time.time()
    # 数据集划分子集
    # encoding = {"ENAC": ENAC2, "binary": binary, "NCP": NCP, "EIIP": EIIP, "Kmer4": Kmer4, "CKSNAP": CKSNAP8,
    #                          "PseEIIP": PseEIIP, "TNC": TNC, "RCKmer5": RCKmer5, "SCPseTNC": SCPseTNC, "PCPseTNC": PCPseTNC,
    #                          "ANF": ANF, "NAC": NAC, "TAC": TAC}
    encoding = {"NCP": NCP}
    data_train1, data_test1 = get_single_data_m7G()
    data_train, data_valid = split_seq_df(data_train1, 0.05)
    y_train_org = get_label(data_train1)
    y_train = get_label(data_train)
    y_dev = get_label(data_valid)
    y_test_org = get_label(data_test1)

    X_train, _ = encoding_all(data_train, encoding)
    X_dev, _ = encoding_all(data_valid, encoding)
    X_test_org, _ = encoding_all(data_test1, encoding)

    print(X_train.shape)

    with open("data/positive_dsTest2.pkl", "rb") as f:
        data_pos = pkl.load(f)

    with open("data/negative_dsTest2.pkl", "rb") as f:
        data_neg = pkl.load(f)

    # -------------------------------------------------------------------------------------------------
    data_test = data_pos["seq"].values.tolist() + data_neg["seq"].values.tolist()
    data_test = [seq1.replace('U', 'T') for seq1 in data_test]
    y_test = [1] * data_pos.shape[0] + [0] * data_neg.shape[0]

    data_test = pd.DataFrame({"label": y_test, "seq": data_test})
    X_test, y_test = encoding_all(data_test, encoding)
    # --------------------------------------------------------------------------------------------------

    pos_train_data = X_train[y_train == 1]
    pos_dev_data = X_dev[y_dev == 1]
    models = []
    n_models = 50 #150
    dev_size = 100 #200
    scaler = 10000
    len_pos = len(pos_train_data)
    len_pos = list(range(len_pos))
    rr_max_list = []
    # =============================tuning parameter for OCSVM====================================================
    for t1 in tqdm(range(n_models), bar_format='{l_bar}%s{bar}%s{r_bar}' % (Fore.RED, Fore.RESET)):
        random.shuffle(len_pos)
        random.shuffle(len_pos)
        random.shuffle(len_pos)
        X_t1 = pos_train_data[len_pos[:dev_size]]
        result_devs = []
        result_tests = []
        params = []
        nus = np.linspace(0.1, 0.2, 20)
        gramas = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2]
        xxx = list(product(nus, gramas))
        for nu1, grama1 in xxx:
            ocsvm = OneClassSVM(kernel='rbf', gamma=grama1, nu=nu1)
            ocsvm.fit(X_t1)
            y_pred1 = ocsvm.decision_function(pos_dev_data)
            y_pred1 = np.array(y_pred1) * scaler
            y_pred1 = 1 / (1 + np.exp(-y_pred1))
            result_dev = score22([1] * len(y_pred1), y_pred1, 0.01)
            result_devs.append(result_dev)
            params.append([nu1, grama1])

        # ----------------------------------------------------------------
        result_devs = np.array(result_devs)
        devs = result_devs[:, 5].tolist()
        index1 = devs.index(max(devs))
        # -----------------------------
        ocsvm_t1 = OneClassSVM(kernel='rbf', gamma=params[index1][1], nu=params[index1][0])
        ocsvm_t1.fit(X_t1)
        results_temp_dev = ocsvm_t1.decision_function(X_dev)
        results_temp_dev = np.array(results_temp_dev) * scaler
        results_temp_dev = 1 / (1 + np.exp(-results_temp_dev))

        models.append(ocsvm_t1)
        # select thre
        rr_max = select_thre(y_dev, results_temp_dev, 10000)
        rr_max_list.append(rr_max)

    end = time.time()
    print("Time consuming:%.2f秒" % (end - start))

    import time

    start = time.time()
    all_preds = []
    all_preds_org = []
    all_preds_dev = []
    for i in tqdm(range(len(models)), bar_format='{l_bar}%s{bar}%s{r_bar}' % (Fore.BLUE, Fore.RESET)):
        thre1 = rr_max_list[i]
        model11 = models[i]

        preds = model11.decision_function(X_test)
        pre_label_acc = np.array(preds) * scaler
        pre_label_acc = 1 / (1 + np.exp(-pre_label_acc))
        pre_label_acc[pre_label_acc > thre1] = 1
        pre_label_acc[pre_label_acc < thre1] = 0
        all_preds.append(pre_label_acc)
        preds_org = model11.decision_function(X_test_org)
        pre_label_acc_org = np.array(preds_org) * scaler
        pre_label_acc_org = 1 / (1 + np.exp(-pre_label_acc_org))
        pre_label_acc_org[pre_label_acc_org > thre1] = 1
        pre_label_acc_org[pre_label_acc_org < thre1] = 0
        all_preds_org.append(pre_label_acc_org)
        preds_dev = model11.decision_function(X_dev)
        pre_label_acc_dev = np.array(preds_dev) * scaler
        pre_label_acc_dev = 1 / (1 + np.exp(-pre_label_acc_dev))
        pre_label_acc_dev[pre_label_acc_dev > thre1] = 1
        pre_label_acc_dev[pre_label_acc_dev < thre1] = 0
        all_preds_dev.append(pre_label_acc_dev)

    all_preds = np.array(all_preds)
    all_preds_mean = all_preds.mean(axis=0)

    all_preds_org = np.array(all_preds_org)
    all_preds_mean_org = all_preds_org.mean(axis=0)

    all_preds_dev = np.array(all_preds_dev)
    all_preds_mean_dev = all_preds_dev.mean(axis=0)

    print("validset-no-thre:", score21(y_dev, all_preds_mean_dev))
    print("testset-no-thre-2 :", score21(y_test, all_preds_mean))
    print("testset-no-thre-1 :", score21(y_test_org, all_preds_mean_org))

    # 总阈值
    # 筛选阈值
    rr_max = select_thre2(y_dev, all_preds_mean_dev, 10000)

    print("validset-thre:", score21(y_dev, all_preds_mean_dev, rr_max))
    print("testset-thre-2:", score21(y_test, all_preds_mean, rr_max))
    print("testset-thre-1:", score21(y_test_org, all_preds_mean_org, rr_max))

    end = time.time()
    print("Time consuming:%.2f秒" % (end - start))

    print("rr_max_list:", rr_max_list)
    print("rr_max_list:", max(rr_max_list), min(rr_max_list))
    print("rr_max:", rr_max)

    end_end = time.time()
    print("Time consuming:%.2f秒" % (end_end - start_start))

