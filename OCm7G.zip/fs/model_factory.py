from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, ExtraTreesClassifier, \
    GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB, GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
import lightgbm


def get_new_model(model_name):
    if model_name == "RF":
        return RandomForestClassifier(criterion="entropy")
    if model_name == "MNB":
        return MultinomialNB()
    if model_name == "AB":
        return AdaBoostClassifier()
    if model_name == "GNB":
        return GaussianNB()
    if model_name == "LD":
        return LinearDiscriminantAnalysis()
    if model_name == "ET":
        return ExtraTreesClassifier(random_state=0, criterion="entropy")
    if model_name == "GB":
        return GradientBoostingClassifier(random_state=0)
    if model_name == "XGB":
        # to remove "warning" by use "eval_metric='logloss'"
        return XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    if model_name == "LR":
        return LogisticRegression(max_iter=10000)
    if model_name == "KNN":
        return KNeighborsClassifier()
    if model_name == "SVM":
        return SVC(kernel='rbf', probability=True)
    if model_name == "LGBM":
        return lightgbm.LGBMClassifier()